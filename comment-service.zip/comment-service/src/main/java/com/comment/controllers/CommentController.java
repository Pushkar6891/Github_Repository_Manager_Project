package com.comment.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.comment.entities.Comment;
import com.comment.repos.CommentRepository;

@RestController
@CrossOrigin("http://localhost:4200")
public class CommentController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CommentController.class);

	@Autowired
	private CommentRepository repository;

	@RequestMapping(value = "/comment/", method = RequestMethod.GET)
	public List<Comment> getAllComment() {
		LOGGER.info("Finding all Comments");
		return repository.findAll();
	}

	@RequestMapping(value = "/comment/{id}/", method = RequestMethod.GET)
	public Comment getComment(@PathVariable("id") int id) {
		LOGGER.info("Finding Comment by id: " + id);
		Optional<Comment> optionalComment = repository.findById(id);
		if (optionalComment.isPresent()) {
			return optionalComment.get();
		} else {
			LOGGER.info("Comment with id: " + id + " absent");
			return null;
		}
	}

	@RequestMapping(value = "/comment/", method = RequestMethod.POST)
	public Comment createComment(@RequestBody Comment comment) {
		LOGGER.info("Comment Created");
		return repository.save(comment);
	}

	@RequestMapping(value = "/comment/{commentId}/", method = RequestMethod.PUT)
	public Comment updateComment(@RequestBody Comment comment, @PathVariable Integer commentId) {
		LOGGER.info("Comment Updated");
		return repository.findById(commentId).map(oldComment -> {
//			oldComment.setCommentId(comment.getCommentId());
//			oldComment.setFavourite_items_name(comment.getFavourite_items_name());
//			oldComment.setFavourite_items_html_url(comment.getFavourite_items_html_url());
			oldComment.setComment_value(comment.getComment_value());
			return repository.save(oldComment);
		}).orElseGet(() -> {
			comment.setComment_id(comment.getComment_id());
			return repository.save(comment);
		});
	}

	@RequestMapping(value = "/comment/{id}/", method = RequestMethod.DELETE)
	public void deleteComment(@PathVariable("id") int id) {
		LOGGER.info("Comment with id: " + id + " deleted");
		repository.deleteById(id);
	}

}
