package com.favourite.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Favourite implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	private int favourite_items_id;
	private String favourite_items_name;
	private String favourite_items_html_url;

	public Favourite() {
	}

	public Favourite(int favourite_items_id, String favourite_items_name, String favourite_items_html_url) {
		super();
		this.favourite_items_id = favourite_items_id;
		this.favourite_items_name = favourite_items_name;
		this.favourite_items_html_url = favourite_items_html_url;
	}

	public int getFavourite_items_id() {
		return favourite_items_id;
	}

	public void setFavourite_items_id(int favourite_items_id) {
		this.favourite_items_id = favourite_items_id;
	}

	public String getFavourite_items_name() {
		return favourite_items_name;
	}

	public void setFavourite_items_name(String favourite_items_name) {
		this.favourite_items_name = favourite_items_name;
	}

	public String getFavourite_items_html_url() {
		return favourite_items_html_url;
	}

	public void setFavourite_items_html_url(String favourite_items_html_url) {
		this.favourite_items_html_url = favourite_items_html_url;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((favourite_items_html_url == null) ? 0 : favourite_items_html_url.hashCode());
		result = prime * result + favourite_items_id;
		result = prime * result + ((favourite_items_name == null) ? 0 : favourite_items_name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Favourite other = (Favourite) obj;
		if (favourite_items_html_url == null) {
			if (other.favourite_items_html_url != null)
				return false;
		} else if (!favourite_items_html_url.equals(other.favourite_items_html_url))
			return false;
		if (favourite_items_id != other.favourite_items_id)
			return false;
		if (favourite_items_name == null) {
			if (other.favourite_items_name != null)
				return false;
		} else if (!favourite_items_name.equals(other.favourite_items_name))
			return false;
		return true;
	}	

}
