package com.favourite.controllers;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.favourite.entities.Favourite;
import com.favourite.repos.FavouriteRepository;

@RestController
@CrossOrigin("http://localhost:4200")
public class FavouriteController {

	private static final Logger LOGGER = LoggerFactory.getLogger(FavouriteController.class);

	@Autowired
	private FavouriteRepository repository;

	@RequestMapping(value = "/favourite/", method = RequestMethod.GET)
	public List<Favourite> getAllFavourite() {
		LOGGER.info("Finding all Favourites");
		return repository.findAll();
	}

	@RequestMapping(value = "/favourite/{id}/", method = RequestMethod.GET)
	public Favourite getFavourite(@PathVariable("id") int id) {
		LOGGER.info("Finding Favourite by id: " + id);
		Optional<Favourite> optionalFavourite = repository.findById(id);
		if (optionalFavourite.isPresent()) {
			return optionalFavourite.get();
		} else {
			LOGGER.info("Favourite with id: " + id + " absent");
			return null;
		}
	}

	@RequestMapping(value = "/favourite/", method = RequestMethod.POST)
	public Favourite createFavourite(@RequestBody Favourite favourite) {
		LOGGER.info("Favourite Created");
		return repository.save(favourite);
	}

	@RequestMapping(value = "/favourite/{favouriteId}", method = RequestMethod.PUT)
	public Favourite updateFavourite(@RequestBody Favourite favourite, @PathVariable Integer favouriteId) {
		LOGGER.info("Favourite Updated");
		return repository.findById(favouriteId).map(oldFavourite -> {
			oldFavourite.setFavourite_items_id(favourite.getFavourite_items_id());
			oldFavourite.setFavourite_items_name(favourite.getFavourite_items_name());
			oldFavourite.setFavourite_items_html_url(favourite.getFavourite_items_html_url());
			return repository.save(oldFavourite);
		}).orElseGet(() -> {
			favourite.setFavourite_items_id(favouriteId);
			return repository.save(favourite);
		});
	}

	@RequestMapping(value = "/favourite/{id}/", method = RequestMethod.DELETE)
	public void deleteFavourite(@PathVariable("id") int id) {
		LOGGER.info("Favourite with id: " + id + " deleted");
		repository.deleteById(id);
	}

}
