//package com.favourite.controllers;
//
//import java.net.URI;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
//
//import com.favourite.entities.Favourite;
//import com.favourite.services.FavouriteHardcodedService;
//@RestController
//@CrossOrigin(origins = "http://localhost:4200")
//public class FavouriteResource {
//
//	@Autowired
//	private FavouriteHardcodedService favouriteService;
//
//	@GetMapping("/users/{username}/favourites")
//	public List<Favourite> getAllFavourites(@PathVariable("username") String username) {
//		return favouriteService.findAll();
//	}
//
//	@DeleteMapping("/users/{username}/favourites/{id}")
//	public ResponseEntity<Void> deleteFavourite(@PathVariable("username") String username, @PathVariable("id") long id) {
//		Favourite favourite = favouriteService.deleteById(id);
//		if (favourite != null) {
//			return ResponseEntity.noContent().build();
//		}
//		return ResponseEntity.notFound().build();
//	}
//
//	@GetMapping("/users/{username}/favourites/{id}")
//	public Favourite getFavourite(@PathVariable("username") String username, @PathVariable("id") long id) {
//		return favouriteService.findById(id);
//	}
//
//	@PutMapping("/users/{username}/favourites/{id}")
//	public ResponseEntity<Favourite> updateFavourite(@PathVariable("username") String username, @PathVariable("id") long id,
//			@RequestBody Favourite favourite) {
//		Favourite favouriteUpdated = favouriteService.save(favourite);
//		return new ResponseEntity<Favourite>(favourite, HttpStatus.OK);
//	}
//
//	
//	@PostMapping("/users/{username}/favourites")
//	public Favourite createFavourite(@PathVariable("username") String username, @RequestBody Favourite favourite) {
//		Favourite createdFavourite = favouriteService.save(favourite);
//		createdFavourite.setFavourite_items_name(username);
//		URI uri = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdFavourite.getFavourite_items_id())
//				.toUri();
//		
//		return createdFavourite;
//	}
//
//}
