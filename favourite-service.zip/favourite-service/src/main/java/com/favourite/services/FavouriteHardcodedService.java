package com.favourite.services;

import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;
import com.favourite.entities.Favourite;

@Service
public class FavouriteHardcodedService {

	private static List<Favourite> favourites = new ArrayList();
	private static int idCounter = 0;
	
	static {
		favourites.add(new Favourite(1, "Facebook", "http://www.api.facebook.com"));
		favourites.add(new Favourite(2, "Twitter", "http://www.api.twitter.com"));
		favourites.add(new Favourite(3, "Linkedin", "http://www.api.linkedin.com"));
	}
	
	public List<Favourite> findAll(){
		return favourites;
	}
	
	public Favourite save(Favourite favourite) {
		if (favourite.getFavourite_items_id() == -1 || favourite.getFavourite_items_id() == 0) {
			favourite.setFavourite_items_id(++idCounter);
			favourites.add(favourite);
		} else {
			deleteById(favourite.getFavourite_items_id());
			favourites.add(favourite);
		}
		return favourite;
	}
	
	public Favourite deleteById(long id) {
		Favourite favourite = findById(id);
		if (favourite == null) {
			return null;
		}
		if (favourites.remove(favourite)) {
			return favourite;
		}

		return null;
	}
	
	public Favourite findById(long id) {
		for (Favourite favourite : favourites) {
			if (favourite.getFavourite_items_id() == id) {
				return favourite;
			}
		}
		return null;
	}
}
