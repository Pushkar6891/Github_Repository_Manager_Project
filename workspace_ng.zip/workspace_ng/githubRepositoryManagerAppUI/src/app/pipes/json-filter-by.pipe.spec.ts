import { JsonFilterByPipe } from './json-filter-by.pipe';

describe('JsonFilterByPipe', () => {
  it('create an instance', () => {
    const pipe = new JsonFilterByPipe();
    expect(pipe).toBeTruthy();
  });
});
