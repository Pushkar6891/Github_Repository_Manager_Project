export class AuthenticationBean {
  constructor(public message: string) {

  }
}
