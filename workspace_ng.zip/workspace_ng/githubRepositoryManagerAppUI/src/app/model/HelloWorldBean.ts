export class HelloWorldBean {
  constructor(public message: string) {

  }
}
