export class FavouriteBean {
    
    favourite_items_id: number;
    favourite_items_name:string;
    favourite_items_html_url:string;

    public getFavouriteItemsId():number{
        return this.favourite_items_id;
    }

    public getFavouriteItemsName():string{
        return this.favourite_items_name;
    }

    public getFavouriteItemsHtmlUrl():string{
        return this.favourite_items_html_url;
    }
  
}

