export class CommentBean {
  
      public comment_id: number;
      public favourite_items_id: number;
      public favourite_items_html_url: string;
      public favourite_items_name: string;
      public comment_value:string;

    public getCommentId(){
      return this.comment_id;
    }

    public getFavouriteItemsId(){
      return this.favourite_items_id;
    }

    public getFavouriteItemsHtmlUrl(){
      return this.favourite_items_html_url;
    }

    public getFavouriteItemsName(){
      return this.favourite_items_name;
    }

    public getCommentValue(){
      return this.comment_value;
    }
  }
  
  