import { Component, OnInit } from '@angular/core';
import { FavouriteService } from '../service/data/favourite.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FavouriteBean } from '../model/FavouriteBean';
import { CommentService } from '../service/data/comment.service';
import { CommentBean } from '../model/CommentBean';

@Component({
  selector: 'app-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

  favourite_items_id: number;
  favourite_items_name: string;
  favourite_items_html_url: string;
  comment_value: string;

  favourites: Array<any> = [];
  comments: Array<any> = [];
  username: string;
  uname: string;

  displayComments: boolean = false;
  id: number;
  message: string;

  startIndex = 0;
  endIndex = 10;

  searchData: string;
  invalidSearch = false;
  errorMessage = '';
  name: string;

  showUpdateCommentTable: boolean = false;
  showAddCommentTable:boolean = false;
  comment_id:number;

  constructor(private service: FavouriteService, private commentService: CommentService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    this.favourite_items_id = parseInt(sessionStorage.getItem('favourite_items_id'));
    this.favourite_items_name = sessionStorage.getItem('favourite_items_name');
    this.favourite_items_html_url = sessionStorage.getItem('favourite_items_html_url');
    this.username = sessionStorage.getItem('username');
    this.getAllCommentsForId();
  }

  public getAFavourite() {
    //this.favourites = [];
    this.uname = this.username;

    this.service.getAFavourite(this.favourite_items_id).subscribe(response => {
      console.log(response);

      for (var i = 0; i < response.length; i++) {
        let favourite = new FavouriteBean();
        favourite.favourite_items_id = response[i].favourite_items_id;
        favourite.favourite_items_name = response[i].favourite_items_name;
        favourite.favourite_items_html_url = response[i].favourite_items_html_url;
        this.favourites.push(favourite);
      }
    }, error => {
      console.log(error);
    });
  }

  postComment(data) {
    this.comment_value = data.comment_value;
    let comment = new CommentBean();
    comment.comment_id = Math.floor((Math.random() * 10000) + 1);
    comment.favourite_items_id = this.favourite_items_id;
    comment.favourite_items_name = this.favourite_items_name;
    comment.favourite_items_html_url = this.favourite_items_html_url;
    comment.comment_value = this.comment_value;
    console.log("Comment Value : " + this.comment_value);
    this.commentService.postComment('pushkar', comment).subscribe((response) => {
      this.message = "Added Comments for Repository with ID: " + this.favourite_items_id + " and Name: " + this.favourite_items_name + " Successful!";
      console.log(response);
    });
  }

  public getAllCommentsForId() {
    this.commentService.getAllComments(this.username).subscribe(response => {
      console.log("Res: " + response);
      this.displayComments = true;
      this.comments = response.filter(element => {
        return element.favourite_items_name === this.favourite_items_name;
      });
      //  this.comments = response;
    });
  }

  public deleteComment(id) {
    this.commentService.deleteComment(id, this.username).subscribe(
      response => {
        this.message = `Deleted Comment with id: ${id} and name ${this.favourite_items_name} Successful!`;
        this.getAllCommentsForId();
      }
    );
  }

  getArrayFromNumber(length) {
    return new Array(length).map((a, i) => {
      return i;
    });
  }

  updateIndex(pageIndex) {
    this.startIndex = pageIndex * 10;
    this.endIndex = this.startIndex + 10;
  }

  public updateComment1(comment_id, comment_value) {
    this.showUpdateCommentTable = true;
    this.comment_id = comment_id;
    this.comment_value = comment_value;
  }

  public updateComment2(data) {
    this.comment_value = data.comment_value;
    // console.log(this.favourite_items_id);
    // console.log(this.favourite_items_name);
    // console.log(this.favourite_items_html_url);
     console.log(this.comment_value);
    // console.log(this.comment_id);
    
     let comment = new CommentBean();
     comment.comment_id = this.comment_id;
     comment.favourite_items_id = this.favourite_items_id;
     comment.favourite_items_name = this.favourite_items_name;
     comment.favourite_items_html_url = this.favourite_items_html_url;
     comment.comment_value = this.comment_value;
     this.commentService.updateComment('pushkar',this.comment_id,comment).subscribe(response=>{
      console.log(response);
      this.message = `Updated Comments for Repository with ID: ${this.favourite_items_id} and Name: ${this.favourite_items_name} with Comment ID : ${this.comment_id} Successful!`;
     },
     (error)=>{
       console.log(error);
     });
  }

}
