import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommentService {

  name: string;
  constructor(private http: HttpClient) {
    this.name = sessionStorage.getItem('name');
  }

  getAllComments(username): Observable<any> {
    return this.http.get("http://localhost:8081/comment/");
  }

  deleteComment(id, username) {
    return this.http.delete("http://localhost:8081/comment/" + id + "/");
  }

  getComment(id): Observable<any> {
    console.log("service called.......");
    return this.http.get("http://localhost:8081/comment/" + id +"/");
  }

  updateComment(username, id, comment) {
    return this.http.put("http://localhost:8081/comment/" + id + "/",comment);
  }

  postComment(username, comment) {
    return this.http.post("http://localhost:8081/comment/",comment);
  }

}
